//>>built
define("dgrid/extensions/nls/fr/columnHider",{popupLabel:"Afficher ou masquer les colonnes"});