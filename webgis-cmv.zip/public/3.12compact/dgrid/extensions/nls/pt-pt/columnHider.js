//>>built
define("dgrid/extensions/nls/pt-pt/columnHider",{popupLabel:"Exibir ou esconder colunas"});