//>>built
define("dgrid/extensions/nls/pl/columnHider",{popupLabel:"Wy\u015bwietl lub ukryj kolumny"});