//>>built
define("dijit/form/nls/lt/Textarea",{iframeEditTitle:"redagavimo sritis",iframeFocusTitle:"redagavimo srities r\u0117melis"});