//>>built
define("dijit/form/nls/lt/ComboBox",{previousMessage:"Ankstesni pasirinkimai",nextMessage:"Daugiau pasirinkim\u0173"});