//>>built
define("dijit/form/nls/et/Textarea",{iframeEditTitle:"muudetav ala",iframeFocusTitle:"muudetava ala raam"});