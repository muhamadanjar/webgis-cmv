//>>built
define("dijit/form/nls/tr/ComboBox",{previousMessage:"\u00d6nceki se\u00e7enekler",nextMessage:"Di\u011fer se\u00e7enekler"});