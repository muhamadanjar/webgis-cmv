//>>built
define("dijit/nls/et/loading",{loadingState:"Laadimine...",errorState:"Kahjuks ilmnes viga"});