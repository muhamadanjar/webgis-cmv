<?php namespace App\Commands;

abstract class Command {

	//

}
